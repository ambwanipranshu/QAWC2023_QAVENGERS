package Basics;

import org.testng.annotations.Test;
import static io.restassured.RestAssured.given;

import java.util.HashMap;
import java.util.List;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class Testpro {
	@Test
	public void test001() {
	
	RestAssured.baseURI = "https://private-f2209f-testapi1238.apiary-mock.com";
	RestAssured.basePath = "/search";

	Response resp = given().get();

	String str =given().get().then().extract().path("query");
	
	System.out.println(str);
	
	//resp.prettyPrint();


	}


@Test
public void test002() {

	RestAssured.baseURI = "https://private-f2209f-testapi1238.apiary-mock.com";
	RestAssured.basePath = "/search";

	Response resp = given().get();

	String str =given().get().then().extract().path("items[0].name");
	
	System.out.println(str);
	
	//resp.prettyPrint();

}


@Test
public void test003() {

	RestAssured.baseURI = "https://private-f2209f-testapi1238.apiary-mock.com";
	RestAssured.basePath = "/search";

	Response resp = given().get();

	HashMap<String, String> map =given().get().then().extract().path("items[0].giftOptions");
	
	System.out.println("Avilable gift options are" +map);
	
	//resp.prettyPrint();

}
 
//find    -->
//findAll  -->




@Test
public void test004() {

	RestAssured.baseURI = "https://private-f2209f-testapi1238.apiary-mock.com";
	RestAssured.basePath = "/search";

	Response resp = given().get();

	int i =given().get().then().extract().path("items.size()");
	
	System.out.println("No of itmes avilable " +i);
	
	//resp.prettyPrint();

}



@Test
public void test005() {

	RestAssured.baseURI = "https://private-f2209f-testapi1238.apiary-mock.com";
	RestAssured.basePath = "/search";

	Response resp = given().get();

	 List<HashMap<String, Object>> list=given().get().then().extract().path("items.findAll{it.name='Apple iPod touch 32 Gb'}");
	
	System.out.println("required info about ipod ::" +list);
	
	//resp.prettyPrint();

}


@Test
public void test006() {

	RestAssured.baseURI = "https://private-f2209f-testapi1238.apiary-mock.com";
	RestAssured.basePath = "/search";

	Response resp = given().get();

	int price=given().get().then().extract().path("items.find{it.name=='Apple iPod touch 32 Gb'}.itemId");
	
	System.out.println("Sale price of ipod ::" +price);
	
	//resp.prettyPrint();

}

}
