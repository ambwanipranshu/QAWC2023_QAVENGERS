package Basics;

import org.json.JSONException;
import org.json.JSONObject;
import org.testng.annotations.Test;
import static io.restassured.RestAssured.given;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class GetAllStudents {
	
	@Test
	public void getallstudent()
	{
		RestAssured.baseURI="http://samples.openweathermap.org";

		
		String resp = given().queryParam("q", "London,uk").queryParam("appid", "439d4b804bc8187953eb36d2a8c26a02")
				 .when().get("/data/2.5/weather").then().log().all().assertThat().statusCode(200).extract().response().asString();

	
		JsonPath js= new JsonPath(resp);
		
		String lat=js.get("base");
		System.out.println("value is "+lat);
		String vis=js.get("weather[0].description");
		System.out.println("value is "+vis);
		int id=js.get("weather[0].id");
		System.out.println("value is "+id);
		float latitude=js.get("coord.lat");
		System.out.println("value is "+latitude);
	}
	
	@Test
	public void addmap() throws IOException, JSONException
	{
		RestAssured.baseURI="https://rahulshettyacademy.com";
		
		HashMap<String,Object> hs =new HashMap();	
		
		hs.put("accuracy", 50);
		hs.put("name","Frontline house");
		hs.put("phone_number", "(+91) 983 893 3937");;
		hs.put("address", "29, side layout, cohen 09");
		hs.put("website", "http://google.com");
		hs.put("language", "French-IN");
		
		HashMap<String,Object> location = new HashMap<String,Object>();
		
		location.put("lat", -38.383494);
		location.put("lng", 33.427362);
		
		hs.put("location", location);
		
		List<String> type = new ArrayList<String>();
		type.add("shoe park");
		type.add("shop");
		
		hs.put("types", type);
		
		String result= new String(Files.readAllBytes(Paths.get("C:\\Users\\abhaysingh09\\Downloads\\AdPlace.json"))); 
		String replacedstring=result.replace("{shop345}", "shop");
		JSONObject modifiedjson=new JSONObject(result);
		modifiedjson.remove("name");
		modifiedjson.put("name","Frontline house");
		System.out.println(replacedstring);
	String response=given().log().all().queryParam("key", "qaclick123").header("Content-type","application/json")
				.body(replacedstring).when().post("maps/api/place/add/json").then().log().all().assertThat().statusCode(200)
				.header("Server", "Apache/2.4.18 (Ubuntu)").extract().response().asString();
		
		
		JsonPath js = new JsonPath(response);
		 String placeID = js.getString("place_id");
		String newaddress="70 winter walk, chicago houson USA ";
		System.out.println(response);
		
//		given().log().all().queryParam("key", "qaclick123").header("Content-type","application/json").body("{\r\n"
//				+ "\"place_id\":\""+placeID +"\",\r\n"
//				+ "\"address\":\""+newaddress+"\",\r\n"
//				+ "\"key\":\"qaclick123\"\r\n"
//				+ "}\r\n"
//				+ "")
//		.when().put("maps/api/place/update/json").then().assertThat().statusCode(200)
//		.body("msg", equalTo("Address successfully updated"));
//		
//		String getresponse = given().queryParam("key", "qaclick123").queryParam("place_id", placeID)
//				 .when().get("maps/api/place/get/json").then().log().all().assertThat().statusCode(200).extract().response().asString();
//
//
//				 JsonPath js1 = new JsonPath(getresponse);
//				 String ActualAddress= js1.getString("address");
//				 System.out.println(ActualAddress);
	}
	
	@Test
	public void jsonread() throws IOException
	{
		String result= new String(Files.readAllBytes(Paths.get("C:\\Users\\abhaysingh09\\Downloads\\complex.json"))); 
		String replacedstring=result.replace("{secondperson}", "Abhay");
		
		System.out.println(replacedstring);
	}

}
